const APP_PATH = '/imdb';

export const routPath = {
  home: `${APP_PATH}/`,
  categories: `${APP_PATH}/categries`,
  invalid:`${APP_PATH}/*`
};
