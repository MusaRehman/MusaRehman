import React from 'react'
import NavBar from '../components/NavBar'
import { useEffect,useState } from 'react';
import { MovieCategories } from '../services/api';
import { NOWPLAYING_API_URL } from '../constants/constants';
import { Box } from '@mui/material';
import Banner from '../components/Banner';
import UpNext from '../components/UpNext.jsx';
import { styled } from '@mui/material';
import Slides from '../components/Slides';
const Wrapper = styled(Box)`
    display:flex;
    padding:20px 0;
`
const Component = styled(Box)`
padding:0 115px;
`


export default function Home() {

  const [movies,setMovies]=useState([]);

  useEffect(()=>{
    const getData= async()=>{

      let responce=await MovieCategories(NOWPLAYING_API_URL);
      setMovies(responce.results);
    }
    getData();
  },[])

  return (
    <>
     <NavBar/>
     <Component>
     <Wrapper>
      <Banner movies={movies}/>
      <UpNext movies={movies}/>
     </Wrapper>
     <Slides movies={movies}/>
     <Slides movies={movies}/>
     <Slides movies={movies}/>
     </Component>
    </>
  )
}
