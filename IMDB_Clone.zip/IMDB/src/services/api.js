import axios from 'axios';


export const MovieCategories = async(API_URL)=>{
    try{
        let responce = await axios.get(API_URL);
        return responce.data;
    }catch(error){
        console.log('Error while calling MovieCategories API !!',error.message);
        return error.rersponce.data;
    }
}
