import React, { useState } from 'react';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import InputBase from '@mui/material/InputBase';
import { styled } from '@mui/system';
import MenuIcon from '@mui/icons-material/Menu';
import BookmarkAddIcon from '@mui/icons-material/BookmarkAdd';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import HeaderMenu from './HeaderMenu';
import { logoURL } from '../constants/constants';
import { useNavigate } from 'react-router-dom';
import {routPath} from '../../src/constants/route.js';


const MyToolbar = styled(Toolbar)`
  background: #121212;
  height: 66px;
  padding: 0 115px !important;
  justify-content: space-between;

  & > * {
    padding: 16px;
  }

  & > div {
    display: flex;
    align-items: center;
    cursor: pointer;

    & > p {
      font-size: 14px;
      font-weight: 600;
    }
  }
`;

const InputSearchField = styled(InputBase)`
  background: #ffffff;
  height: 30px;
  width: 55%;
  border-radius: 4px;
`;

const Logo = styled('img')({
  width: '64px',
});

export default function NavBar() {
  const [open, setOpen] = useState(null);

  const navigate =useNavigate();

  const handleClick = (e) => {
    setOpen(e.currentTarget);
  };

  const handleClose = () => {
    setOpen(null);
  };

  return (
    <AppBar position="static">
      <MyToolbar>
        <Logo src={logoURL} alt="Logo" onClick={()=>navigate(routPath.home)} />
        <Box onClick={handleClick}>
          <MenuIcon />
          <Typography>Menu</Typography>
        </Box>
        <HeaderMenu open={open} handleClose={handleClose} />
        <InputSearchField />
        <Typography>
          IMDb
          <Box component="span">Pro</Box>
        </Typography>
        <Box>
          <BookmarkAddIcon />
          <Typography>WatchList</Typography>
        </Box>
        <Typography>Sign In</Typography>
        <Box>
          <Typography>EN</Typography>
          <ExpandMoreIcon />
        </Box>
      </MyToolbar>
    </AppBar>
  );
}
