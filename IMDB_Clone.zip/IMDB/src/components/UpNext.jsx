import { Typography,styled } from '@mui/material'
import React from 'react'
import {Box} from "@mui/material"

const Component = styled(Box)`
    width:40%;
    display:flex;
    flex-direction:column;
    align-items:baseline;
    padding-left:12px;
    & > p{
      color:yellow;
      font-weight:650;
      font-size:15px;
      margin-bottom:10px;
     
    }
`
const Posetr = styled('img')({
  width:88
})

const Wrapper = styled(Box)`
    color:#FFFFFF;
    display:flex;
    &>p{
      margin-left:20px
    }
`

export default function UpNext({movies}) {
  return (
    <>
     <Component>
        <Typography>
        Up Next
        </Typography>
        {
                movies.slice(0,3).map(movie=>(
                    <Wrapper>
                            <Posetr src={`https://image.tmdb.org/t/p/original/${movie.backdrop_path}`}alt="poster"/>
                            <Typography>{movie.original_title}</Typography>
                    </Wrapper>
                ))
        }
     </Component> 
    </>
  )
}
