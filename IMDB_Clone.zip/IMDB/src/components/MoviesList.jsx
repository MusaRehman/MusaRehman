import React from 'react';
import { List, ListItem, Typography,styled } from '@mui/material';
import StarIcon from '@mui/icons-material/Star';


const Banner = styled('img')({
    width:160

})
const Container = styled(List)`
    display:flex;
`
export default function MoviesList({ movies }) {
  return (
    <div>
      {movies.map((movie) => (
        <Container key={movie.id}>
          <ListItem>
            <Banner src={`https://image.tmdb.org/t/p/w500/${movie.poster_path}`} alt="poster" />
          </ListItem>
          <ListItem>
            <Typography>{movie.original_title}</Typography>
            
          </ListItem>
          <ListItem>
          <StarIcon color="warning" />
            <Typography>{movie.vote_average}</Typography>
          </ListItem>
          <ListItem>
            Release Date:  
            <Typography>{movie.release_date}</Typography>
          </ListItem>
        </Container>
      ))}
    </div>
  );
}
