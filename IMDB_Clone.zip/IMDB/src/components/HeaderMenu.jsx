import React from 'react'
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import { Link } from 'react-router-dom';
import { routPath } from '../constants/route';

export default function HeaderMenu({open,handleClose}) {
    const openMenu = Boolean(open);
  return (
    <div>
    <Menu
    id="demo-positioned-menu"
    aria-labelledby="demo-positioned-button"
    anchorEl={open}
    open={openMenu}
    onClose={handleClose}
    anchorOrigin={{
      vertical: 'top',
      horizontal: 'left',
    }}
    transformOrigin={{
      vertical: 'top',
      horizontal: 'left',
    }}
  >
  <Link to={`${routPath.categories}?category=popular`}style={{textDecoration:"none",color:"inherit"}}>
    <MenuItem onClick={handleClose}>Popular</MenuItem>
    </Link>
    <Link  to={`${routPath.categories}?category=toprated`} style={{textDecoration:"none",color:"inherit"}}>
    <MenuItem onClick={handleClose}>Top Rated</MenuItem>
    </Link>
    <Link to={`${routPath.categories}?category=upcoming`} style={{textDecoration:"none",color:"inherit"}}>
    <MenuItem onClick={handleClose}>Upcoming</MenuItem>
    </Link >
    </Menu>
    </div>
  )
}
