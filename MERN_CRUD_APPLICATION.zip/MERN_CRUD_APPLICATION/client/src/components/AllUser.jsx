import {Table,styled,TableHead,TableBody,TableRow,TableCell, Button} from '@mui/material';
import { useEffect ,useState} from 'react';
import {getUsers,deleteUser} from '../service/api';
import {Link} from 'react-router-dom';
const StyledTable = styled(Table)`
width:90%;
margin-top:50px;
margin:auto;
matgin-left:200px;

`
const Thaed=styled(TableRow)`
background: #000000;
&>th{
    color:white;
    font-size:20px
}
`
const Tbody = styled(TableRow)`
&>td{
font-size:20px;
}
`

const AllUser = () =>{

    const [users,setUsers] = useState([]);

useEffect(()=>{
    getAllUsers();

},[]);

    const getAllUsers =async()=>{
      let responce=   await getUsers();
      setUsers(responce.data);
      
    }

    const deleteUserDet = async(id)=>{
        await deleteUser(id);
        getAllUsers();
    }

    return(
       <StyledTable>
        <TableHead>
            <Thaed>
                <TableCell>ID</TableCell>
                <TableCell>Name</TableCell>
                <TableCell>userName</TableCell>
                <TableCell>Phone</TableCell>
                <TableCell>
                </TableCell>
            </Thaed>
        </TableHead>
        <TableBody>
            {
                users.map(user=>(
                    <Tbody key={user._id}>
                        <TableCell>{user._id}</TableCell>
                        <TableCell>{user.name}</TableCell>
                        <TableCell>{user.username}</TableCell>
                        <TableCell>{user.phone}</TableCell>
                        <TableCell></TableCell>
                        <Button variant="contained"style={{marginRight:10}} component={Link}to={`/edit/${user._id}`}>Edit</Button>
                        <Button variant="contained"color="secondary" onClick={()=>deleteUserDet(user._id)}>Delete</Button>
                    </Tbody>
                ))
}
        </TableBody>
       </StyledTable>
    )
}
export default AllUser;