import React from "react";
import { Typography } from '@mui/material';
import './Codeforinterview.css';

const Codeforinterview = () => {
  return (
    <div>
      <div className="navbar">
        <ul className="navindex">
          <li className="navchild">Home</li>
          <li className="navchild">About</li>
          <li className="navchild">Event</li>
          <li className="navchild">Locations</li>
        </ul>
      </div>
      <div className="banner">
        <img src="../img/bannerImage.png" alt="Nature" className="responsive" />
      </div>
      <div className="bannerparent">
        <div className="bleft">
          <h1>The Importance of the 10 Days of Dhul Hajjah</h1>
        </div>
        <div className="bright">
          <img src="./img/cloud.png" alt="" />
        </div>
      </div>
      <div className="cards">
        <div className="loccards">
          <img src="../img/section3logo1.png" alt="" />
          <h2>Location</h2>
          <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Eos beatae fugit nam, suscipit praesentium, dolorem temporibus similique velit perspiciatis quisquam aliquid ab, illo dolorum saepe deleniti iste voluptate veritatis qui doloribus molestiae odit iure!</p>
        </div>
        <div className="mescards">
          <img src="./img/section3logo2.png" alt="" />
          <h2>Location</h2>
          <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Eos beatae fugit nam, suscipit praesentium, dolorem temporibus similique velit perspiciatis quisquam aliquid ab, illo dolorum saepe deleniti iste voluptate veritatis qui doloribus molestiae odit iure!</p>
        </div>
        <div className="datcards">
          <img src="./img/section3logo3.png" alt="" srcSet="" />
          <h2>Location</h2>
          <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Eos beatae fugit nam, suscipit praesentium, dolorem temporibus similique velit perspiciatis quisquam aliquid ab, illo dolorum saepe deleniti iste voluptate veritatis qui doloribus molestiae odit iure!</p>
        </div>
      </div>
      <div className="mos">
        <div className="twomos">
          <h1>This year's Dhul Hijjah</h1>
          <img src="./img/section4Mosque.png" alt="" />
        </div>
        <div className="threemos">
          <h3>Salah</h3>
          <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quos tenetur soluta repellat. Exercitationem aperiam beatae in quisquam ut repudiandae recusandae.</p>
          <h3>Fasting</h3>
          <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quos tenetur soluta repellat. Exercitationem aperiam beatae in quisquam ut repudiandae recusandae.</p>
          <h3>Qur'aan</h3>
          <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quos tenetur soluta repellat. Exercitationem aperiam beatae in quisquam ut repudiandae recusandae.</p>
        </div>
      </div>
      <h1 className="letterhead">Register to our Newsletter!</h1>
      <div className="formqq">
        <form action="">
          <div className="formp">
            <div className="fch1"><input type="text" placeholder="First Name*" /></div>
            <div className="fch2"><input type="text" placeholder="Last Name*" /></div>
          </div>
          <div className="jj">
            <div className="fchm"><input type="email" placeholder="Enter Email*" /></div>
          </div>
          <div className="kk">
            <div className="fchm"><input type="text" placeholder="Write Something here....." /></div>
          </div>
          <button className="btn">Submit Email</button>
        </form>
      </div>
      <footer>
        <h1 className="ftr">Dhul hijjah</h1>
        <div className="pftr">
          <div className="chiftr"><a href="">Home</a></div>
          <div className="chiftr"><a href="">About</a></div>
          <div className="chiftr"><a href="">Events</a></div>
          <div className="chiftr"><img src="./img/socialMediaicons.png" alt="" /></div>
        </div>
      </footer>
    </div>
  );
}

export default Codeforinterview;
