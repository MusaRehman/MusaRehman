import './App.css';
import AddUser from'../src/components/AddUser';
import Navbar from'../src/components/Navbar';
import AllUser from '../src/components/AllUser';
import Codeforinterview from './components/Codeforinterview';
import EditUser from './components/Edituser';

import {BrowserRouter,Routes,Route} from 'react-router-dom';

function App() {
  return (
  
    <BrowserRouter>
    <Navbar/>
    <Routes>
         <Route path='/' element={<Codeforinterview/>} />
         <Route path='/all'element={<AllUser/>}/>
         <Route path='/add'element={<AddUser/>}/>
         <Route path='/edit/:id' element={<EditUser/>}/>
    </Routes>
    </BrowserRouter>
  
  );
}

export default App;
