import mongoose from 'mongoose';

const Connection = async (username,password) => {
  const URL = `mongodb://${username}:${12345}@ac-zd00xfx-shard-00-00.s8smckc.mongodb.net:27017,ac-zd00xfx-shard-00-01.s8smckc.mongodb.net:27017,ac-zd00xfx-shard-00-02.s8smckc.mongodb.net:27017/PROJECT0?ssl=true&replicaSet=atlas-klii49-shard-0&authSource=admin&retryWrites=true&w=majority`;

  try {
    await mongoose.connect(URL, { useUnifiedTopology: true, useNewUrlParser: true });
    console.log('Database Connect hogaya!!!');
  } catch (error) {
    console.log('Error While connecting database!!!', error);
  }
};

export default Connection;
